1. Prepare a SD card with FaT32 fomat.
2. Copy "firmware.bin" into root directory of the SD card
3. Insert the prepared micro SD card into printer, then reboot the printer
4. Waiting until progress finish.
5. All done. Have fun :)